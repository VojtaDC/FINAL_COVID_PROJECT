#include "patientmenu.h"

PatientMenu::PatientMenu(QWidget *parent) : QMainWindow(parent) {
	ui.setupUi(this);
}

